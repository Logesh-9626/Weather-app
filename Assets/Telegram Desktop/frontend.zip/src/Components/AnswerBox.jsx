

const AnswerBox = () => {
  return (
    <div className="container d-flex justify-content-center mt-3 h-100">
     
       <p></p>
    </div>
  )
}

export default AnswerBox