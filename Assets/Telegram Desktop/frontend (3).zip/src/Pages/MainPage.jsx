
import AnswerBox from "../Components/AnswerBox";
import QuestionInput from "../Components/QuestionInput";
const MainPage = () => {
  return (
    <div>
      <AnswerBox/>
      <QuestionInput />
    </div>
  );
};

export default MainPage;
