import React, { useContext, useEffect } from "react";
import { Link } from "react-router-dom";
import { UserContext } from "../Contexts/UserContext";
import axios from "axios";
const SubmissionPage = () => {
  const { CombineData } = useContext(UserContext);
  const createPlanUrl = "http://localhost:3000/api/user/plan";

  useEffect(() => {
    const data = CombineData();
    createprofile(data);
  }, [CombineData]);


  const createprofile = async (data) => {
    console.log(data)
    try {
      const response = await axios.post(createPlanUrl, data);
      console.log(`succuess ${response.data}`)
    } catch (error) {
      console.log(error);
    }
   
  };
  

  return (
    <div className="min-vh-100 d-flex justify-content-center align-items-center">
      <div className="text-center">
        <h1>success!</h1>
        <Link to={"/login"}>
          <button className="btn btn-primary">LogIn</button>
        </Link>
      </div>
    </div>
  );
};

export default SubmissionPage;
