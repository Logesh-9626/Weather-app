import { createContext, useState } from "react";

export const UserContext = createContext();

export const UserReg = ({ children }) => {
  const [userRegData, setUserRegData] = useState(null);
  const [userPlanData, setUserPlanData] = useState(null);
  const saveUserRegData = (formdata) => {
    setUserRegData(formdata);
    console.log("save");
  };

  const saveUserPlanData = (planData) => {
    setUserPlanData(planData);
  };

  const CombineData = () => {
    const UserFullData = {
      ...userRegData,
      plan: userPlanData,
    };
    return UserFullData;
  };

  
  return (
    <UserContext.Provider
      value={{
        userPlanData,
        userRegData,
        saveUserRegData,
        saveUserPlanData,
        CombineData
      }}
    >
      {children}
    </UserContext.Provider>
  );
};
