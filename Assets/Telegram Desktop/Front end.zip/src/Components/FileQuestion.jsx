import React from "react";

const FileQuestion=()=>{
    return(
        <>
      <div className="container d-flex flex-column align-content-center flex-wrap justify-content-end " >
            <input type="text" className="form-control w-50 rounded-pill shadow-lg p-3 mt-3 border-0 " placeholder="Ask your questions..."style={{ backgroundColor: "#77b1b5" }}/>
          </div>
        </>
    )
}

export default FileQuestion;