import React from "react";

const FileAnswer=()=>{
    return(
<div>
<div className="container" >
            <input type="text" className="form-control w-50 rounded-pill shadow-lg p-3 mt-3 border-0 " placeholder="Ask your questions..."style={{ backgroundColor: "#77b1b5" }}/>
    </div>
</div>
    )
}

export default FileAnswer;