import React, { useEffect, useState } from 'react'
import "./App.css"
import "./index.css"
import axios from 'axios';
import Current from "./Components/Current/Current"
import Forecast from './Components/Forecast/Forecast';
import "../node_modules/bootstrap/dist/js/bootstrap"






const App = () => {
  const [input, setInput] = useState("");
  const [cityName, setCityName] = useState([]);
  const [current, setCurrent] = useState();
  const [forecast, setForecast] = useState();
  const [clickedCity, setClickedCity] = useState()
  const [location, setLocation] = useState();
  const [theme, setTheme] = useState("light")



  // auto complete api url
  const autoComURl = "https://api.weatherapi.com/v1/search.json?key=5ca920fe238341c6b1443724241510&q="

  // weather api url
  const weatherApi = `https://api.weatherapi.com/v1/forecast.json?key=5ca920fe238341c6b1443724241510&q=${cityName}&days=7&aqi=no&alerts=no`


  // fetch the autocomplete api
  useEffect(() => {
    if (input, input.length > 3) {
      fetchAutoCom()
    }

  }, [input])

  // fetch the autocomplete api
  const fetchAutoCom = async () => {
    try {
      const response = await axios.get(autoComURl + input);
      const resp = await response.data;
      console.log(resp);
      const fetchData = resp.map((data) => {
        return `${data.name},${data.region},${data.country}`
      });
      setCityName(fetchData);

    } catch (error) {
      console.log(error)
    }
  }

  // handle the citysuggestion click event
  const handleClick = (data) => {
    setClickedCity(data)
    fetchWeather(data);
    setInput("");
    setCityName([])
  }

  // fetch the weather data
  const fetchWeather = async (data) => {
    try {
      const response = await axios.get(weatherApi);
      const resp = response.data;
      console.log(resp);
      setCurrent(resp.current);

      setForecast(resp.forecast);
      setLocation(resp.location);



    } catch (error) {
      console.log(error)
    }
  }
  const handleThemeToggle = () => {
    setTheme(theme === "light" ? "dark" : "light")
    console.log(theme)
  }


  return (
    <>
      <div className={` root ${theme}`} >
        {/* search box */}
        <div className="text-center p-3">
          <div className='conatiner input'>
            <h4 className='text-fluid logo'>Weather BRO</h4>
            <input type="text" value={clickedCity} className={` p-2 w-50 ${theme}`} placeholder='Search city' onChange={(e) => {
              setInput(e.target.value)
              if (e.target.value === "") {
                return (
                  setCurrent(),
                  setLocation(),
                  setForecast(),
                  setClickedCity()

                )
              }
            }} />
            {/* theme toggler */}
            <button className='btn' onClick={handleThemeToggle}><i className={`bi bi-sun ${theme}`}></i></button>
          </div>

          {/* cityname suggestion panel */}
          {cityName && cityName.map((data, index) => {
            return (<div type="button" key={index} className={`cityname mt-2 ${theme}`} role='button' onClick={() => { handleClick(data) }}>{data}</div>)
          })}
        </div>
        
        <div className="row">
          <div className="col-lg-6 col-md-6 col-sm-12">
            {/* current weather section */}

            {current && <Current current={current} location={location} theme={theme} />}
          </div>

          <div className="col-lg-6 col-md-6 col-sm-12">
            {/* forecast Weather */}

            {forecast && <Forecast forecast={forecast} location={location} theme={theme} />}

          </div>
        </div>

      </div>

    </>
  )
}

export default App