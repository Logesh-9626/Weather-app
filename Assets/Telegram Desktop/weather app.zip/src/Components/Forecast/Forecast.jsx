import React from 'react'
import "./Forecast.css"



const Forecast = ({ forecast, theme }) => {

 
  return (
    <>

      <div id="carouselExampleControls" className="container carousel slide" data-bs-ride="carousel">
        <div className="carousel-inner">
          {forecast.forecastday.map((data, index) => {
            
            return (
              <div key={index} className="carousel-item  active">
                <div className="row text-center ">
                  <div className='col-lg-3 col-md-4 col-sm-6'>
                    <div className={`card carouselcard ${theme}`}>
                      <div className="card-body">
                        <p className='card-text'>  {data.date}</p>
                        <img src={data.day.condition.icon} className='image-fluid w-5 h-5' alt="" />
                        <p className='card-text'>{data.day.condition.text}</p>
                      </div>
                    </div>
                  </div>
                  <div className='col-lg-3 col-md-4 col-sm-6'>
                    <div className={`card carouselcard ${theme}`}>
                      <div className="card-body">
                        <p className='card-text'>Max.Temp</p>
                        <i className="bi bi-thermometer-half"></i>
                        <p className='card-text'>{data.day.maxtemp_c}°C</p>
                      </div>
                    </div>
                  </div>
                  <div className='col-lg-3 col-md-4 col-sm-6'>
                    <div className={`card carouselcard ${theme}`}>
                      <div className="card-body">
                        <p className='card-text'>Avg.Temp</p>
                        <i className="bi bi-thermometer-half"></i>
                        <p className='card-text'>{data.day.
                          avgtemp_c}°C</p>
                      </div>
                    </div>
                  </div>
                  <div className='col-lg-3 col-md-4 col-sm-6'>
                    <div className={`card carouselcard ${theme}`}>
                      <div className="card-body">
                        <p className='card-text'>Min.Temp</p>
                        <i className="bi bi-thermometer-half"></i>
                        <p className='card-text'>{data.day.maxtemp_c}°C</p>
                      </div>
                    </div>
                  </div>
                  <div className='col-lg-3 col-md-4 col-sm-6'>
                    <div className={`card carouselcard ${theme}`}>
                      <div className="card-body">
                        <p className='card-text'>Sunrise</p>
                        <i className="bi bi-brightness-high"></i>
                        <p className='card-text'>{data.astro.sunrise}</p>
                      </div>
                    </div>
                  </div>
                  <div className='col-lg-3 col-md-4 col-sm-6'>
                    <div className={`card carouselcard ${theme}`}>
                      <div className="card-body">
                        <p className='card-text'>Sunset</p>
                        <i className="bi bi-brightness-high-fill"></i>
                        <p className='card-text'>{data.astro.sunset}</p>
                      </div>
                    </div>
                  </div>
                  <div className='col-lg-3 col-md-4 col-sm-6'>
                    <div className={`card carouselcard ${theme}`}>
                      <div className="card-body">
                        <p className='card-text'>Moonrise</p>
                        <i className="bi bi-moon"></i>
                        <p className='card-text'>{data.astro.moonrise}</p>
                      </div>
                    </div>
                  </div>
                  <div className='col-lg-3 col-md-4 col-sm-6'>
                    <div className={`card carouselcard ${theme}`}>
                      <div className="card-body">
                        <p className='card-text'>Moonset</p>
                        <i className="bi bi-moon-fill"></i>
                        <p className='card-text'>{data.astro.moonset}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            
            )
          }
          )}

        </div>
        <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
          <span className="carousel-control-prev-icon " aria-hidden="true"></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
          <span className="carousel-control-next-icon " aria-hidden="true"></span>
          <span className="visually-hidden">Next</span>
        </button>
      </div>
     
     {/* hourly forecast */}

     <div className={`container  ${theme}`}>
    <div className='container  hourforecast 'style={{ overflow: 'auto', height: '250px',marginTop:"50px" }}>
      
   
      {forecast.forecastday.map((data, index) => {
        return (
       
          <div key={index} className={`accordion accordion-flush mt-3 rounded-5 ${theme}`} id="accordionFlushExample ">
            <div className="accordion-item ">
              <h2 className="accordion-header" id="flush-headingOne">
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target={`#${index}`} aria-expanded="false" aria-controls="flush-collapseOne">
                  <div className="container accordion d-flex flex-row bd-highlight align-items-center ">
                    <div className="p-2 bd-highlight">Date: {data.date}</div>
                    <div className="p-2 bd-highlight">
                      <img src={data.day.condition.icon} alt=""style={{width :"25px",height:"25px"}} />{data.day.condition.text}
                      </div>
                    <div className="p-2 bd-highlight">Avg.Temp: {data.day.
                      avgtemp_c} °C</div>
                    <div className="p-2 bd-highlight">Max.Temp: {data.day.
                      maxtemp_c} °C</div>
                  </div>
                </button>
              </h2>
              <div id={`${index}`} className="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                <div className="accordion-body">
                  {data.hour.map((data,index) => {
                    return (
                      <div key={index} className={`container forecast ${theme}`}>
                        <div className='d-flex gap-5'>
                          <div> Time:{data.time} </div>
                          <div>Temp:{data.temp_c}°C</div>
                          <div><img src={data.condition.icon} alt="" style={{width :"25px",height:"25px"}}/>{data.condition.text}</div>
                        </div>

                        <div className="progress mt-2">
                          <div className="progress-bar" role="progressbar" style={{ width: `${data.temp_c}%` }} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">{data.temp_c}°C</div>
                        </div>
                      </div>

                    )
                  })}
                </div>
              </div>
            </div>
          </div>
        )
      })}
      

      </div>
    </div>
    </>
  )
}
export default Forecast