import React from 'react'

const Message = ({ current, location }) => {

    let weather = current.condition.text;
    let message;
  
    switch (weather) {
        case "Clear":
            message = "Enjoy the clear skies! It's a beautiful day.";
            break;
          case "Partly cloudy":
            message = "Partly cloudy today. Perfect for a light jacket and sunglasses.";
            break;
          case "Cloudy":
            message = "Cloudy skies ahead. Don't forget your umbrella.";
            break;
          case "Overcast":
            message = "It's overcast today. Stay dry and warm.";
            break;
          case "Sunny":
            message = "Sunny day! Grab your sunglasses and sunscreen.";
            break;
          case "Fog":
            message = "Foggy conditions. Drive carefully and use your headlights.";
            break;
          case "Mist":
            message = "Misty morning. Be cautious while driving.";
            break;
          case "Drizzle":
            message = "Light drizzle is falling. Grab a light jacket.";
            break;
          case "Rain":
            message = "It's raining outside! Don't forget your umbrella.";
            break;
          case "Snow":
            message = "Snowfall is expected. Bundle up and stay warm.";
            break;
          case "Sleet":
            message = "Sleet is falling. Be cautious on icy roads.";
            break;
          case "Hail":
            message = "Hail is possible. Seek shelter if necessary.";
            break;
          case "Thunderstorm":
            message = "A thunderstorm is approaching. Stay indoors and avoid unnecessary travel.";
            break;
          default:
            message = "Enjoy the climate condition.";
        }
    
    return (
        <div className='conatainer'>
            <h6>{location.name} Buddies : {message}</h6>
           
        </div>
    )

}
export default Message