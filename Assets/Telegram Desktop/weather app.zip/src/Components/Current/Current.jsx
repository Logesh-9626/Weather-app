import React from 'react'
import "./Current.css"
import Message from './Message'



const Current = ({ current, location, theme }) => {

  return (
    <>

      <div className='m-4'>
        <div className='panel-1 '>
          <div className="row">
            <div className="col-lg-6 p-4 ">
              <div className='d-flex align-items-center gap-2'>
                <i className='bi bi-geo-alt fs-5'></i>
                <h3 className='text'>
                  {location.name}
                </h3>
              </div>
              <h6 className='text ms-3'>
                {location.region},{location.country}
              </h6>

              <h1 className='text ms-3 mt-3'>{current.temp_c}°C</h1>

            </div>
            <div className="col-lg-6 p-3 text-center  ">

              <img src={current.condition.icon} alt="" className='image-fluid  h-50' />

              <h4 className='text'>{current.condition.text}</h4>

            </div>
            
          </div>

<marquee behavior="" direction=""><Message current={current} location={location}/></marquee>
        </div>
      </div>
      <div className="panel-2">
        <div className="row  text-center">
          <div className="col-lg-4 col-sm-6">
            <div className={`card ${theme}`}>
              <div className="card-body">
                <h6>dewpoint</h6>
                <i className="bi bi-thermometer-half"></i>
                <p className='card-text text-fluid'>{current.
                  dewpoint_c}°C</p>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-sm-6">
            <div className={`card ${theme}`}>
              <div className="card-body">
                <h6>dewpoint</h6>
                <i className="bi bi-thermometer-half"></i>
                <p className='card-text text-fluid'>{current.
                  dewpoint_f
                }°F</p>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-sm-6">
            <div className={`card ${theme}`}>
              <div className="card-body">
                <h6>Humidity</h6>
                <i className="bi bi-water"></i>
                <p className='card-text text-fluid' >{current.
                  humidity
                }</p>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-sm-6">
            <div className={`card ${theme}`}>
              <div className="card-body">
                <h6>Pressure</h6>
                <i className="bi bi-moisture"></i>
                <p className='card-text text-fluid'>{current.
                  pressure_in}In</p>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-sm-6">
            <div className={`card ${theme}`}>
              <div className="card-body">
                <h6>Pressure</h6>
                <i className="bi bi-moisture"></i>
                <p className='card-text text-fluid'>{current.
                  pressure_mb
                }mb</p>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-sm-6">
            <div className={`card ${theme}`}>
              <div className="card-body">
                <h6>Cloud</h6>
                <i className="bi bi-cloud"></i>
                <p className='card-text text-fluid'>{current.
                  cloud
                }</p>
              </div>
            </div>
          </div>
        </div>
      </div>

    </>

  )
}

export default Current