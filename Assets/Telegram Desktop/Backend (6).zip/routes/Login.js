var express = require('express');
var RegisterSchema = require('./model/RegisterSchema.js');
var router = express.Router();
var bcrypt =require("bcrypt")
var jwt =require('jsonwebtoken')
var {hashPassword}=require('../bcryptUtiles.js')

/* GET home page. */
router.get('/Login', function(req, res, next) {
  res.render('index', { title: 'Express' }

  );
});


router.post('/Login', async function(req, res, next) {

    const {email,password}=req.body
    console.log(email,password)
    
       try{  // Verify email for login module
         const UserDetails = await RegisterSchema.findOne({ email });
         if (!UserDetails) {
             return res.status(401).json({
                status:false,
                message: "User Not Found"
             });
         }
 
         // Validate password
         const isValidPassword = await bcrypt.compare(password, UserDetails.hashPassword);
         if (!isValidPassword) {
             return res.status(401).json({
                status:false,
                 message: "Invalid Password"
             });
         }
 
         // Check if plan has expired
         const CurrentDate = new Date();
         if (CurrentDate > UserDetails.expiryDate) {
             return res.status(401).json({
                status:false,
                 message: "Plan Expired, Please Upgrade Your Plan!"
             });
         }
 
         // Generate JWT token
         const Token = jwt.sign({email},process.env.JWTSECRET,{ expiresIn: "1h" });
         res.status(200).json({
             message: "Success",
             Token
         });
 
     } catch (e) {
         console.error("Error:", e);
         res.status(500).json({
             message: "An error occurred",
             error: e.message
         });
     }
   
  });



module.exports = router;
