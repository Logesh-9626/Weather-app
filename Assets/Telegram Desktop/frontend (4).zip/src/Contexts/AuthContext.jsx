import { useContext,useState,createContext,useEffect} from "react";
import axios from "axios"

 export const AuthContext = createContext()

export const AuthContextProvider = ({children}) => {
    const [isAuthenticated,setIsAuthenticated] = useState(false);
 const verifyAuth = async()=>{
    try {
        const response = await axios.get("/protected",{withCredentials:true})  
          if(response.status === 200){
              setIsAuthenticated(true)
              console.log(isAuthenticated)
          }

      } catch (error) {
          setIsAuthenticated(false);
          console.log(isAuthenticated)
          console.log(error)
      }

 }

    // useEffect(()=>{
    //    verifyAuth();
    // },[])

  return (
    <AuthContext.Provider value={{isAuthenticated,verifyAuth}}>
        {children}
    </AuthContext.Provider>
  )
}


