import { createContext, useState,useEffect } from "react";

export const UserContext = createContext();

export const UserReg = ({ children }) => {
  const [userRegData, setUserRegData] = useState(null);
  const [userPlanData, setUserPlanData] = useState(null);
  const [userFullData, setUserFullData] = useState(null);
  const [message ,setMessage] = useState(null)
  const saveUserRegData = (formdata) => {
    setUserRegData(formdata);
    console.log("save");
  };

  const saveUserPlanData = (planData) => {
    // setUserPlanData(planData);
    // console.log(planData);
    // console.log(userPlanData);
    const UserFullData = {
      ...userRegData,
      plan: planData,
    };
    console.log(UserFullData)
    localStorage.setItem("userfulldata",JSON.stringify(UserFullData));
    // setUserFullData(UserFullData);
    
  };

 

    const saveMessage = (message)=>{
        setMessage(message)
    }

  // useEffect(() => {
  //   // CombineData();
  //   if (userFullData) {
  //     const store = localStorage.setItem("userfulldata",userFullData);
  //     console.log(store)
  //   }
  // }, [userPlanData]);
  const CombineData = () => {
    // const UserFullData = {
    //   ...userRegData,
    //   plan: userPlanData,
    // };

    // setUserFullData(UserFullData);
  };

  return (
    <UserContext.Provider
      value={{
        userPlanData,
        userRegData,
        saveUserRegData,
        saveUserPlanData,
        userFullData,
        saveMessage,
        message
      }}
    >
      {children}
    </UserContext.Provider>
  );
};
