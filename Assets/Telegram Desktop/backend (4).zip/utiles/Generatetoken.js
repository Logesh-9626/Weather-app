import jwt from "jsonwebtoken";

const generatetoken = (res,userId) =>{
    const isProduction = process.env.NODE_ENV
    const token = jwt.sign({userId},process.env.SECRET_KEY,{expiresIn : "10h"})

    res.cookie("token",token,{
        httpOnly : true,
        secure : isProduction,
        maxAge : 10 * 3600000,
        sameSite : isProduction ? "strict" : "lax"
    })
}

export default generatetoken;